$(document).ready(function() {

  $("#place").focus();
  
  $("#login").focus();															 

  $(function() {

    $("#sidebar").jScroll({top : 50});

  });
  
  //get default place value when page first loads
  var place_default=$("#place").val();

  //if click in place, clear it
  $("#place").click(function() {
      if ($(this).val() == place_default) {
          $(this).val("");
      }
  });
	
	//if click away from place, if empty replace with default
  $("#place").blur(function() {
      if ($(this).val() == "") {
          $(this).val(place_default);
      }
  });  

});

