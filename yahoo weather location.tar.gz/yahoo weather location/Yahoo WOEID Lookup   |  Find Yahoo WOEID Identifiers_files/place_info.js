$(document).ready(function() {

  get_ajax_data();

  //if results row clicked send data- attributes contained in row
  $('.woeid_row').live('click', function() {
    get_ajax_data($(this).data());
  });


  function get_ajax_data(location_data){
  
    if(!location_data) {
    
      location_data = {use_session: 1}
    
    }

    var csrf_token_value = $.cookie('ci_csrf_token');
    $(".place_info").html("");
    $(".place_info").addClass("spinner");
    
    $(".place_info").load("/place_info/get_place_info_display_ajax", {

      postdata:location_data, ci_csrf_token:csrf_token_value      

    },
      function(){
  
        $(".place_info").removeClass("spinner");
  
   		});
  
  }

															 

});

