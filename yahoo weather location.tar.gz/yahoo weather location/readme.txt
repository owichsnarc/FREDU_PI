This is used to get your world co-ordinate id so that we can use real location when running 
~/programming/neopixels_banggood_copies/alarmpi-master/get_weather_yahoo.py

this program and all the programs in this directory use a config file called alarm.config
which contains various configuration details for programs that run within this directory.
The one that concerns us in this instance is under the [weather_yahoo] named location
use the web page in this directory to input your postcode or location you want to get an id for 
, copy the 8 digit down and replace my location=12345678 with your location=#########
# being your numbers :)

below just for reference is the config file afore mentioned
If you fancy getting rich the tickers refered to under stocks are fb = facebook pot.nz = port of Ta? in new zealand

and if you want to get really rich :) take a look at the get_BTC.py program in 
~/programming/neopixels_banggood_copies/alarmpi-master/

sudo python get_BTC.py
run it a few times and see when to buy and when to sell ........... it rose 300 dollars last year 2015-2016
think about it !!!!! LiL4Li3N


#GNU nano 2.2.6                                                             File: #alarm.config                                                                                                                                  

[main]
enabled=1
debug=1
readaloud=1
trygoogle=1
head=wget -q -U Mozilla
tail=.mp3
end=Thats all for now.  Have a nice day.
light=1
lightdelay=1
music=1
musicfldr=/Music

[greeting]
enabled=1
name=Chris

[birthday]
enabled=1

[weather_yahoo]
enabled=1
location=26756466
metric=1
# Change units to Imperial by changing metric=0
wind=1
# wind is available only with metric
wind_chill=1
# default set from November - March
#I need this because it's cold kitesurfing

[btc]
enabled=1

[stocks]
enabled=1
tickers=fb,bt,pot.nz

[news]
enabled=1

