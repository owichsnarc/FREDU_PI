from RPLCD import CharLCD, cleared, cursor
lcd = CharLCD()

smiley = (
     0b00000,
     0b01010,
     0b01010,
     0b00000,
     0b10001,
     0b10001,
     0b01110,
     0b00000,
)
lcd.create_char(0, smiley)
lcd.write_string(unichr(0))
