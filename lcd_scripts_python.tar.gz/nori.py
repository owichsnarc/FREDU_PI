# LCD Python LiL4Li3n 
# 19/02/2016
#
#
#!/usr/bin/env python3

import time

import RPi.GPIO as GPIO

from RPLCD import CharLCD, cleared, cursor





lcd = CharLCD(cols=16, rows=2,

                pin_rw=None,

                pin_rs=7,

                pin_e=8,

                pins_data=[25,24,23,18],

                numbering_mode=GPIO.BCM)



lcd.write_string('LiL4Li3N Soft')

lcd.cursor_pos = (1, 0)

lcd.write_string('Systems &')

time.sleep (5)

lcd.cursor_pos = (1, 8)

lcd.write_string('Hardware')

time.sleep (20);

lcd.cursor_pos = (0, 14)

smiley = (
     0b00000,
     0b01010,
     0b01010,
     0b00000,
     0b10001,
     0b10001,
     0b01110,
     0b00000,
)
lcd.create_char(0, smiley)
lcd.write_string(unichr(0))
time.sleep (5)
lcd.cursor_pos = (0, 14)
smiley2 = (
     0b11111,
     0b10101,
     0b10101,
     0b11111,
     0b01110,
     0b01110,
     0b10001,
     0b11111,
)
lcd.create_char(0, smiley2)
lcd.write_string(unichr(0))

time.sleep (2)
lcd.cursor_pos = (0,14)
lcd.create_char(0, smiley)
lcd.write_string(unichr(0))
time.sleep (2)
lcd.cursor_pos = (0,14)
lcd.create_char(0, smiley2)
lcd.write_string(unichr(0))
time.sleep (1)
lcd.cursor_pos = (0,14)
lcd.create_char(0, smiley)
lcd.write_string(unichr(0))
time.sleep (1)
lcd.cursor_pos = (0,14)
lcd.create_char(0, smiley2)
lcd.write_string(unichr(0))
