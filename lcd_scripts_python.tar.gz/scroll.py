# LCD Python LiL4Li3n 
# 19/02/2016
#
#
#!/usr/bin/env python3

##

#

framebuffer = [
    'Hello!',
    '',
]



def write_to_lcd(lcd, framebuffer, num_cols):
     """Write the framebuffer out to the specified LCD."""
     lcd.home()
     for row in framebuffer:
         lcd.write_string(row.ljust(num_cols)[:num_cols])
         lcd.write_string('\r\n')

from RPLCD import CharLCD
lcd = CharLCD()
write_to_lcd(lcd, framebuffer, 16)

