# LCD Python LiL4Li3n 
# 19/02/2016
#
#
#!/usr/bin/env python3

import time

import RPi.GPIO as GPIO

from RPLCD import CharLCD, cleared, cursor





lcd = CharLCD(cols=16, rows=2,

                pin_rw=None,

                pin_rs=7,

                pin_e=8,

                pins_data=[25,24,23,18],

                numbering_mode=GPIO.BCM)



lcd.write_string('PenguinTutor.com')

lcd.cursor_pos = (1, 0)

lcd.write_string('This is line 2')

time.sleep (5)

lcd.cursor_pos = (1, 8)

lcd.write_string('row:')

time.sleep (20);



smiley = (
     0b00000,
     0b01010,
     0b01010,
     0b00000,
     0b10001,
     0b10001,
     0b01110,
     0b00000,
)
lcd.create_char(0, smiley)
lcd.write_string(unichr(0))
