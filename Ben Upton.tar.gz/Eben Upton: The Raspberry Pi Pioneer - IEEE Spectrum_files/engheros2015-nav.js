jQuery(document).ready(function(){
var report_stories = [
	{
				'path':'/geek-life/profiles/eben-upton-the-raspberry-pi-pioneer',
				'img_alt':'Eben Upton headshot',
				'img_src':'/img/HREbenUptonDanBurnForti67314-140px-1425065536142.jpg',
				'hed':'Eben Upton: The Raspberry Pi Pioneer',
				'dek':'He just wanted to help some kids learn to code. Five million units later, his $35 computer has sparked a revolution'
	},
	{		
				'path':'/geek-life/profiles/manuela-veloso-robocups-champion',
				'img_alt':'Manuela Veloso headshot',
				'img_src':'/img/HRRossMantle8271-140px-1425065304597.jpg',
				'hed':'Manuela Veloso: RoboCup\u2019s Champion',
				'dek':'This roboticist has transformed robot soccer into a global phenomenon'
	},
	{	
				'path':'/geek-life/profiles/ashok-gadgil-the-humanitarian-inventor',
				'img_alt':'Ashok Gadgil headshot',
				'img_src':'/img/HRGabrielaHasbunGadgil24631-140px-1425065458852.jpg',
				'hed':'Ashok Gadgil: The Humanitarian Inventor',
				'dek':'His work on water purification, cookstoves, and arsenic removal has helped tens of millions of people worldwide'
	},
	{	
				'path':'/geek-life/profiles/topher-white-repurposing-cellphones-to-defend-the-rain-forest',
				'img_alt':'Topher White headshot',
				'img_src':'/img/HRGabrielaHasbunWhite18108-140px-1425065401572.jpg',
				'hed':'Topher White: Repurposing Cellphones to Defend the Rain Forest',
				'dek':'His networks of solar-powered phones can detect the sounds of illegal logging'
	},
	{	
				'path':'/geek-life/profiles/brian-monks-keeping-bogus-electronics-out-of-consumers-hands',
				'img_alt':'Brian Monks headshot',
				'img_src':'/img/HRBrianMonksbyDavidYellen36970-140px-1425065194606.jpg',
				'hed':'Brian Monks: Keeping Bogus Electronics Out of Consumers\u2019 Hands',
				'dek':'This engineer at Underwriters Labs is a counterfeiter\u2019s worst nightmare'
	},
	{	
				'path':'/biomedical/devices/robert-malkin-macgyvering-medical-gear',
				'img_alt':'Robert Malkin headshot',
				'img_src':'/img/HRDLAndersonRobertMalkin150121-140px-1425065497477.jpg',
				'hed':'Robert Malkin: MacGyvering Medical Gear',
				'dek':'He is inspiring students to tackle urgent problems in the developing world'
	},
	{	
				'path':'/geek-life/profiles/christopher-soghoian-shining-a-light-on-government-snooping',
				'img_alt':'Christopher Soghoian headshot',
				'img_src':'/img/4mYH_Rli3WDq390W13Rg94g-1425069543326.jpg',
				'hed':'Christopher Soghoian: Shining a Light on Government Snooping',
				'dek':'The ACLU\u2019s technologist exposes attacks on privacy by government agencies and corporate collaborators'
	}	
];

var currentpath = window.location.pathname;
var currentIndex = -1;


for (var i=0;i<report_stories.length-1;i++) {
	var story = report_stories[i].path;
	if (report_stories[i].path == currentpath) {
		currentIndex = i;
	}
}

var nextIndex = currentIndex + 1;

var navBox = '<div class="item thumb-list" id="report-next"><div class="thumb"><a href="'+report_stories[nextIndex].path+'"><img alt="'+report_stories[nextIndex].img_alt+'" src="'+report_stories[nextIndex].img_src+'"></a></div><div class="next-article-arrow"><a href="'+report_stories[nextIndex].path+'"><img src="/img/unfilled-arrow-1364578665223.png"></a></div><div class="content"><ul class="inline-list breadcrumb"><li><a href="/static/engineering-heroes-2015">2015 Engineering Heroes</a></li><li class="sep">|</li><li><a class="tag" href="'+report_stories[nextIndex].path+'">Next Hero</a></li></ul><h3><a href="'+report_stories[nextIndex].path+'">'+report_stories[nextIndex].hed+'</a></h3><p>'+report_stories[nextIndex].dek+'</p></div></div>';
	
jQuery('#artBody').append(navBox);

});